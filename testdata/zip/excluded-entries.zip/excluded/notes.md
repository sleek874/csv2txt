This unsupported extension should be skipped.
